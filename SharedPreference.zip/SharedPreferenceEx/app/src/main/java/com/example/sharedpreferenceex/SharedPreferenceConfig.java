package com.example.sharedpreferenceex;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceConfig
{


    private SharedPreferences m_sharedPreferences;
    private Context m_context;
    public SharedPreferenceConfig(Context context)
    {
        m_context = context;
        m_sharedPreferences = context.getSharedPreferences
                (context.getResources().getString(R.string.login_preference),Context.MODE_PRIVATE);

    }
    public  void writeLoginStatus(Boolean status)
    {

        SharedPreferences.Editor editor= m_sharedPreferences.edit();
        editor.putBoolean(m_context.getResources().getString(R.string.login_status_preference),status);
        editor.commit();

    }


    public boolean readLoginStatus(){

        boolean status =false;
        status= m_sharedPreferences.getBoolean(m_context.getResources().getString(R.string.login_status_preference),false);
        return status;
    }




}
