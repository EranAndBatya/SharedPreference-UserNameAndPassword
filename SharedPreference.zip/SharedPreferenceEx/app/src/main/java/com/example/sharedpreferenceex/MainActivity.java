package com.example.sharedpreferenceex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private SharedPreferenceConfig m_preferenceConfig;
    private EditText m_user_name,m_user_password;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m_preferenceConfig= new SharedPreferenceConfig((getApplicationContext()));
        m_user_name= findViewById(R.id.username);
        m_user_password=findViewById((R.id.password));
        if(m_preferenceConfig.readLoginStatus())
        {
            startActivity(new Intent(this,SuccessActivity.class));
            finish();
        }

    }

    public void loginUser(View view)
    {
        String userName =m_user_name.getText().toString();//cin
        String user_password =m_user_password.getText().toString();//cin
        if (userName.equals(getResources().getString(R.string.name))&&
                user_password.equals(getResources().getString(R.string.password)))
        {
            startActivity(new Intent(this,SuccessActivity.class));
            m_preferenceConfig.writeLoginStatus(true);
            finish();

        }
        else{
            Toast.makeText(this,"Login Failed.. Try again ",Toast.LENGTH_SHORT).show();
            m_user_name.setText("");
            m_user_password.setText("");
        }

    }
}
